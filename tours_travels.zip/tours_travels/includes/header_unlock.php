
  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top bg-theme-color-2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="widget no-border m-0">
              <ul class="list-inline">
                <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-white"></i> <a class="text-white" href="tel:8485861499">8485861499</a> </li>
                <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-white"></i> <a class="text-white" href="mailto:ksanket1398@gmail.com">ksanket1398@gmail.com</a> </li>
              </ul>
            </div>
          </div>
          <div class="col-md-6">
            <div class="widget no-border m-0">
              <ul class="list-inline text-right sm-text-center">
			  <li>
				<li class="text-white"><a class="text-white" href="./participant_registration.php">Participant Registration <span class="label label-success"> New</span></a></li>
                </li>
				<li class="text-white">|</li>
				<li>
				<li class="text-white"><a class="text-white" target="_blank" href="./participant/index.php">Participant Login </a></li>
                </li>
				<li class="text-white">|</li>
                  <a href="./admin/login.php" target="_blank" class="text-white">Admin Login</a>
				  
								
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default">
            <a class="menuzord-brand pull-left flip" href="javascript:void(0)">
              <img src="images/logo-wide.png" width="200px" class="img-responsive" alt="">
            </a>
            <ul class="menuzord-menu">
              <li class="active"><a href="./login.php">Login</a>
              </li>
			  <li><a href="./about.php">About Us</a></li>
               <li><a href="./rules.php">Rules</a></li>
               <li><a href="./nomination.php">Nominations</a></li>          
			  <li><a href="./competition.php">Competition</a></li>			  	
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>
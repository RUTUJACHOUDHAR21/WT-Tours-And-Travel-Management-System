
  <!-- Header -->
  <header id="header" class="header">
    <div class="header-top bg-theme-color-2 sm-text-center">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <div class="widget no-border m-0">
              <ul class="list-inline">
                <li class="m-0 pl-10 pr-10"> <i class="fa fa-phone text-white"></i> <a class="text-white" href="tel:9999999999">9999999999</a> </li>
                <li class="m-0 pl-10 pr-10"> <i class="fa fa-envelope-o text-white"></i> <a class="text-white" href="mailto:bagwantours@gmail.com">bagwantours@gmail.com</a> </li>
              </ul>
            </div>
          </div>
          <div class="col-md-6">
            <div class="widget no-border m-0">
              <ul class="list-inline text-right sm-text-center">
			  <?php if($login_session)  
				{   
					$status="Welcome ".$login_name; 
					$url="http:./logout.php";
					$status1="Logout";  
				}
				else
				{ 
					$status="Welcome Guest"; 
					$url="http:./login.php";
					$status1="Login"; 
				 }
				  ?>
			  <li>
				<li class="text-white"><a class="text-white" href="<?php echo  $url; ?>"><?php echo $status;?></a></li>
                </li>
				<li class="text-white">|</li>
				<li>
				<li class="text-white"><a class="text-white"  href="<?php echo  $url; ?>"><?php echo $status1; ?></a></li>
                </li>
				<li class="text-white">|</li>
                  <a href="./admin/login.php" target="_blank"  class="text-white">Admin Login</a>

								
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="header-nav">
      <div class="header-nav-wrapper navbar-scrolltofixed bg-white">
        <div class="container">
          <nav id="menuzord-right" class="menuzord default">
            <a class="menuzord-brand pull-left flip" href="javascript:void(0)">
              <img src="images/logo-wide.png" width="200px" class="img-responsive" alt="">
            </a>
            <ul class="menuzord-menu">
              <li><a href="./index.php">Book Trip</a></li>
              <li><a href="./my_booked_packages.php">My Booked Trips</a></li>
              <li><a href="./book_custom_trip.php">Book Custom Trip</a></li>
              <li><a href="./my_booked_custom_trip.php">My Custom Trips</a></li>
			  <!--<li><a href="./about.php">About Us</a></li>
			  <li><a href="./contact.php">Contact Us</a></li>-->
            </ul>
          </nav>
        </div>
      </div>
    </div>
  </header>
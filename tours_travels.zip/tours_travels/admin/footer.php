<footer class="footer-default" style="position: static;  bottom: 0;  width: 100%;  height: 30px;  background-color: #f5f5f5;">
  <div class="container-fluid default">
    <p class="text-muted credit" align="center">Design & Developed By Project Team Copyrights &copy; 2019</p>
  </div>
</footer>
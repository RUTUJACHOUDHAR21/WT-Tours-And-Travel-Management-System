<?php
$login_session="" ;
 $url="";
 $status="";
 include('lock.php');
 include ("conn.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <title> Payment Report  </title>
  <link rel="shortcut icon" type="image/x-icon" href="./images/favicon.ico" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

 <link rel="stylesheet" href="./resources/bootstrap-3.3.6-dist/css/bootstrap.min.css">
  <script src="./resources/bootstrap-3.3.6-dist/js/jquery.min.js"></script>
  <script src="./resources/bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
  <script src="./sss.js"></script>
</head>
<body>
<?php
include('./header.php');
?>




<div class="container" style="margin-top:20px">
<div class="row">
<div class="col-md-12">

<div class="panel panel-info">
      <div class="panel-heading" align="center">Payment Report</div>
      <div class="panel-body">
        <div class='table-responsive'>
      <?php
      //include('conn.php');
      error_reporting(E_ALL);
	  $today=date('Y-m-d');
      $sql = "SELECT eu.euid, eu.euname, eu.eumob, p.paidamt, p.pdate FROM payment p, end_user eu WHERE eu.euid=p.euid AND p.status=1 ORDER BY eu.euid ASC";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
        // output data of each row       
          echo "<table class='table table-striped'>
          <thead>
            <tr>
              <th>ID</th>
              <th>User Name</th>
			  <th>Mobile Number </th>			  
              <th>Amount </th>
              <th>Paid Date </th>
            </tr>
          </thead>
          <tbody>";
          while($row = $result->fetch_assoc()) {
            
           echo"<tr>";             
              echo "<td>".$row['euid']."</td>";
              echo "<td>".$row['euname']."</td>";
              echo "<td>".$row['eumob']."</td>";
              echo "<td>".$row['paidamt']."</td>";
              echo "<td>".$row['pdate']."</td>";          
           echo "</tr>";
         }
           
          echo"</tbody>
      </table>";
        
        }  
        else {
         echo "0 results";
        }
        $conn->close();
        ?> 
      </div>
      </div><!-- Close panel Body -->

</div> <!-- Close Panel -->
</div>


</div> <!-- Close Row -->


</div> <!-- Close Container -->



<?php
include('footer.php');
?>
</body>
</html>
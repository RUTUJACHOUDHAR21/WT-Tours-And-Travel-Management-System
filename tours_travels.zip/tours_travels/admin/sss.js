function delete_vehicle(vid = null) {
	if(vid) {
		var r = confirm("Are You Sure To Delete Vehicle?");
		if(r==true){
			$.ajax({
				url: './delete_vehicle.php',
				type: 'post',
				data: {vid : vid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Vevhicle Deleted Successfully!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
function delete_package(tpid = null) {
	if(tpid) {
		var r = confirm("Are You Sure To Delete Package?");
		if(r==true){
			$.ajax({
				url: './delete_package.php',
				type: 'post',
				data: {tpid : tpid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Package Deleted Successfully!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
function delete_offer(oid = null) {
	if(oid) {
		var r = confirm("Are You Sure To Delete Offer?");
		if(r==true){
			$.ajax({
				url: './delete_offer.php',
				type: 'post',
				data: {oid : oid},
				dataType: 'json',
				success:function(response) {			
					if(response.success == true) {						
						 location.reload();
						 alert("Offer Deleted Successfully!");
						 $("#mes").html("ookkk");
					} else {
					          
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
// remove order from server
function approve_business(bid = null) {
	if(bid) {
		var r = confirm("Are You Sure To Approve Business?");
		if(r==true){
			$.ajax({
				url: './approve_business.php',
				type: 'post',
				data: {bid : bid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Business Approve Successfully!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
// remove order from server
function reject_business(bid = null) {
	if(bid) {
		var r = confirm("Are You Sure To Reject Business?");
		if(r==true){
			$.ajax({
				url: './reject_business.php',
				type: 'post',
				data: {bid : bid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Business Rejected Successfully!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
// remove order from server
function approve_feedback(fid = null) {
	if(fid) {
		var r = confirm("Are You Sure To Show Comment Publicly?");
		if(r==true){
			$.ajax({
				url: './approve_feedback.php',
				type: 'post',
				data: {fid : fid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Comment Is Displaying on Website!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
// remove order from server
function reject_feedback(fid = null) {
	if(fid) {
		var r = confirm("Are You Sure To Hide Comment from Publicly?");
		if(r==true){
			$.ajax({
				url: './reject_feedback.php',
				type: 'post',
				data: {fid : fid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Comment Is Rejected on Website!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
// remove order from server
function delete_cat(cid = null) {
	if(cid) {
		var r = confirm("Are You Sure To Delete Catagory?");
		if(r==true){
			$.ajax({
				url: './delete_cat.php',
				type: 'post',
				data: {cid : cid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Catagory Deleted Successfully!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
// remove order from server
<?php
$login_session="" ;
 $url="";
 $status="";
 include('lock.php');
 include('conn.php');
$error="";
$show="display:none;";
$alert="";
if (isset($_POST['submit'])){
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
	 $root = test_input($_POST["root"]);
	 $price = test_input($_POST["price"]);
	 $tpname = test_input($_POST["tpname"]);
	 $duration = test_input($_POST["duration"]);
	 $time = test_input($_POST["time"]);
	 $map = $_POST["map"];
	 $vid = test_input($_POST["vid"]);
     $sql = "SELECT * FROM trip_package WHERE root='$root' AND vid=$vid AND status=1";
	 $query = $conn->query($sql);
	 $count = $query->num_rows;
      if ($count >0){
        $error="Your Root Is Already Exist!";
        $show="display:show;";
        $alert="alert alert-danger";		
      }
	  else{
		$sql = "INSERT INTO trip_package (root, price, tpname, duration, time, map, status,  regdate, uid, vid) 
		VALUES ('$root',$price,'$tpname','$duration','$time','$map',1, @now := now(), $user_id, $vid)";
		if($conn->query($sql)===TRUE){
			$error="Your Trip Package Is Added Successfully!";
			$show="display:show;";
			$alert="alert alert-success";
		}
		else{
			$error="Proccess Is Invalid!";
			$show="display:show;";
			$alert="alert alert-success";
		}
	  }
	}
}

function test_input($data) {
	$data = trim($data);
	$data = stripslashes($data);
	$data = htmlspecialchars($data);
	return $data;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
 <title> Manage Trip Packages  </title>
  <link rel="shortcut icon" type="image/x-icon" href="./images/favicon.ico" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

 <link rel="stylesheet" href="./resources/bootstrap-3.3.6-dist/css/bootstrap.min.css">
  <script src="./resources/bootstrap-3.3.6-dist/js/jquery.min.js"></script>
  <script src="./resources/bootstrap-3.3.6-dist/js/bootstrap.min.js"></script>
  <script src="./sss.js"></script>
</head>
<body>
<?php
include('./header.php');
?>




<div class="container" style="margin-top:20px">
<div class="row">
    <div class="col-md-12">
      <div align="center" class="<?php echo $alert; ?>" role="alert" style="<?php echo $show; ?>"><?php echo $error; ?></div>
      
    </div> <!-- close col-->
  </div> <!--close row-->
<div class="row">

  <div class = "col-md-4">
<!--<div class="alert alert-success alert-sm" role="alert" id="signalert" style="display:show;">Well done! You successfully Signup!</div> -->
<div class="panel panel-info">
      <div class="panel-heading" align="center">Add Trip Package </div>
      <div class="panel-body">

 <form enctype="multipart/form-data" data-toggle="validator" role="form" method="post" action="">
<div class="form-group">
        <label class="control-label">Select Vehicle </label>
            <select class="form-control" id="vid" name="vid" required>
              <option value="">Select Vehicle Number</option>
      <?php
        $query = "SELECT vid, vno from vehicle where status=1";
        $result = $conn->query($query);  
            while($row = $result->fetch_assoc()) {                                                 
            echo "<option value='".$row['vid']."'>".$row['vno']."</option>";
            }
        ?>     
            </select>
    </div>
  <div class="form-group">
   <label class="control-label">Enter Trip Root</label>
    <input class="form-control" type="text" id="root" name= "root" placeholder="Enter Trip Root" required>
  </div>
  <div class="form-group">
   <label class="control-label">Enter Package Price</label>
    <input class="form-control" type="number" id="price" name= "price" placeholder="Enter Package Price" required>
  </div>
  <div class="form-group">
   <label class="control-label">Enter Trip Name</label>
    <input class="form-control" type="text" id="tpname" name= "tpname" placeholder="Enter Package Name" required>
  </div>
  <div class="form-group">
   <label class="control-label">Enter Trip Duration</label>
    <input class="form-control" type="text" id="duration" name= "duration" placeholder="Enter Trip Duration" required>
  </div>
  <div class="form-group">
   <label class="control-label">Enter Trip Time</label>
    <input class="form-control" type="text" id="time" name= "time" placeholder="Enter Trip Time" required>
  </div>
  <div class="form-group">
   <label class="control-label">Trip Map Location</label>
    <textarea class="form-control" rows="4" id="map" name= "map"  required></textarea>
  </div>
  <div class="form-group" align="center">
    <button type="submit" class="btn btn-info" name="submit">Add Trip Package</button>
  </div>

</form>

</div> <!-- Close panel Body -->

</div> <!-- Close Panel -->

</div> <!-- Close Col -->

<div class="col-md-8">

<div class="panel panel-info">
      <div class="panel-heading" align="center">Package Details</div>
      <div class="panel-body">
        <div class='table-responsive'>
      <?php
      include('./conn.php');
      error_reporting(E_ALL);
      $sql = "SELECT * FROM trip_package tp, vehicle v WHERE v.vid=tp.vid AND tp.status=1 order by tp.trpid asc;";
      $result = $conn->query($sql);
      if ($result->num_rows > 0) {
          echo "<table class='table table-striped'>
          <thead>
            <tr>
              <th>Trip Root</th>
              <th>Trip Price</th>
              <th>Trip Name</th>
              <th>Trip Duration</th>
              <th>Trip Time</th>
              <th>Vehicle</th>
              <th>Added Date</th>
              <th>Action</th>
           </tr>
          </thead>
          <tbody>";
          while($row = $result->fetch_assoc()) {            
           echo"<tr>";
              echo "<td>".$row['root']."</td>";
              echo "<td>".$row['price']."</td>";
              echo "<td>".$row['tpname']."</td>";
              echo "<td>".$row['duration']."</td>";
              echo "<td>".$row['time']."</td>";
              echo "<td>".$row['vno']."</td>";
              echo "<td>".$row['regdate']."</td>";
              echo  "<td> <button type='submit' class='btn btn-default btn-sm' onclick='delete_package(".$row['trpid'].")' name ='btndel' id='btndel'> <span class='glyphicon glyphicon-trash'></span> Delete</button></td>";
           echo "</tr>";
         }
           
          echo"</tbody>
      </table>";
        
        }  
        else {
         echo "0 results";
        }
        $conn->close();
        ?> 
      </div>
      </div><!-- Close panel Body -->

</div> <!-- Close Panel -->
</div>


</div> <!-- Close Row -->


</div> <!-- Close Container -->


<?php
include('footer.php');
?>
</body>
</html>
// remove order from server
function cancel_booking(tbid = null) {
	if(tbid) {
		var r = confirm("Are You Sure to Cancel Booking?");
		if(r==true){
			$.ajax({
				url: './cancel_booking.php',
				type: 'post',
				data: {tbid : tbid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Booking Cancel Successfully!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}
function cancel_custom_booking(cbid = null) {
	if(cbid) {
		var r = confirm("Are You Sure to Cancel Custom Trip Booking?");
		if(r==true){
			$.ajax({
				url: './cancel_custom_booking.php',
				type: 'post',
				data: {cbid : cbid},
				dataType: 'json',
				success:function(response) {
					if(response.success == true) {
						 location.reload();
						 alert("Custom Trip Booking Cancel Successfully!");
						 $("#mes").html("ookkk");
					} else {
					} // /else
				} // /success
			});  // /ajax function to remove the order
	} else{
		location.reload();
	}
	}
	else {
		alert('error! refresh the page again');
	}	
}

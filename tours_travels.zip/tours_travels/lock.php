<?php
include('conn.php');
$lsess=date('Y-m-d');
if(!isset($_SESSION)){
    session_start();
}
if(isset($_SESSION['login_euser']))
{
$user_check=$_SESSION['login_euser'];
 $ses_sql=$conn->query("select euname, eumob, euid from end_user where eumob='$user_check' ");
 while($row = $ses_sql->fetch_assoc()) {
    $user_id = $row['euid'];
    $login_session=$row['eumob'];
    $login_name=$row['euname'];
}
}
else
{
	header("Location:./login.php");  	
}
?>
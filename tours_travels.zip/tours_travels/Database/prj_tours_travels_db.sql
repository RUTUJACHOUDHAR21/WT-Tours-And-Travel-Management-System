-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 22, 2020 at 09:46 AM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `prj_tours_travels_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `custom_booking`
--

CREATE TABLE `custom_booking` (
  `cbid` int(9) NOT NULL,
  `trip_date` date NOT NULL,
  `trip_time` varchar(50) NOT NULL,
  `source` varchar(30) NOT NULL,
  `desti` varchar(30) NOT NULL,
  `tripdistance` double(10,2) NOT NULL,
  `vid` int(9) NOT NULL,
  `euid` int(9) NOT NULL,
  `regdate` date NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `custom_booking`
--

INSERT INTO `custom_booking` (`cbid`, `trip_date`, `trip_time`, `source`, `desti`, `tripdistance`, `vid`, `euid`, `regdate`, `status`) VALUES
(1, '2020-03-17', '10 AM', 'Manchar', 'Bhimashankar', 0.00, 4, 1, '2020-03-15', 0),
(2, '2020-03-19', '10 AM', 'Manchar', 'Bhimashankar', 0.00, 4, 1, '2020-03-15', 1),
(3, '2020-03-19', '10 AM', 'Manchar', 'Bhimashankar', 0.00, 4, 1, '2020-03-15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `end_user`
--

CREATE TABLE `end_user` (
  `euid` int(9) NOT NULL,
  `euname` varchar(30) NOT NULL,
  `eumob` varchar(10) NOT NULL,
  `eupass` int(15) NOT NULL,
  `euadd` varchar(100) NOT NULL,
  `eubdate` date NOT NULL,
  `euregdate` date NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `end_user`
--

INSERT INTO `end_user` (`euid`, `euname`, `eumob`, `eupass`, `euadd`, `eubdate`, `euregdate`, `status`) VALUES
(1, 'admin', '8888789402', 123, 'su@gma.dd', '1990-02-19', '2020-03-14', 1),
(2, 'admin', '9960613401', 123, 'sdsd@dfdf.dfd', '1990-02-02', '2020-03-14', 1),
(3, 'Subhan', '9975508577', 123, 'Subhan@gamil.com', '1990-02-19', '2020-03-15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `fid` int(9) NOT NULL,
  `comment` varchar(900) NOT NULL,
  `comm_date` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `euid` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`fid`, `comment`, `comm_date`, `status`, `euid`) VALUES
(1, 'sdvdsvdfsv', '2020-03-15', 1, 1),
(2, 'good', '2020-03-15', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `oid` int(9) NOT NULL,
  `datefrom` date NOT NULL,
  `dateto` date NOT NULL,
  `description` varchar(900) NOT NULL,
  `imgpath` varchar(90) NOT NULL,
  `regdate` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `trpid` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`oid`, `datefrom`, `dateto`, `description`, `imgpath`, `regdate`, `status`, `trpid`) VALUES
(1, '2020-03-16', '2020-03-20', 'nnnnn', 'uploads/offers/1_20200315014755.jpg', '2020-03-15', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `pid` int(9) NOT NULL,
  `paidamt` double(10,2) NOT NULL,
  `euid` int(9) NOT NULL,
  `pdate` date NOT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`pid`, `paidamt`, `euid`, `pdate`, `status`) VALUES
(1, 4000.00, 1, '2020-03-15', 1),
(2, 1000.00, 1, '2020-03-15', 1),
(3, 4000.00, 1, '2020-03-15', 1),
(4, 4000.00, 1, '2020-03-15', 1),
(5, 150.00, 1, '2020-03-15', 1),
(6, 1200.00, 1, '2020-03-15', 1),
(7, 150.00, 1, '2020-03-15', 1),
(8, 150.00, 1, '2020-03-15', 1);

-- --------------------------------------------------------

--
-- Table structure for table `trip_booking`
--

CREATE TABLE `trip_booking` (
  `tbid` int(9) NOT NULL,
  `trip_date` date NOT NULL,
  `regdate` date NOT NULL,
  `status` tinyint(4) NOT NULL,
  `trpid` int(11) NOT NULL,
  `euid` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trip_booking`
--

INSERT INTO `trip_booking` (`tbid`, `trip_date`, `regdate`, `status`, `trpid`, `euid`) VALUES
(1, '2020-03-17', '2020-03-15', 0, 2, 1),
(2, '2020-03-18', '2020-03-15', 0, 2, 1),
(3, '2020-03-17', '2020-03-15', 1, 2, 1),
(4, '2020-03-16', '2020-03-15', 1, 2, 1),
(5, '2020-03-16', '2020-03-15', 0, 2, 1),
(6, '2020-03-16', '2020-03-15', 1, 2, 2),
(7, '2020-03-19', '2020-03-15', 1, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `trip_package`
--

CREATE TABLE `trip_package` (
  `trpid` int(9) NOT NULL,
  `root` varchar(50) NOT NULL,
  `price` double(10,2) NOT NULL,
  `tpname` varchar(20) NOT NULL,
  `duration` varchar(250) NOT NULL,
  `time` varchar(35) NOT NULL,
  `map` varchar(500) NOT NULL,
  `status` tinyint(4) NOT NULL,
  `regdate` date NOT NULL,
  `uid` int(9) NOT NULL,
  `vid` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `trip_package`
--

INSERT INTO `trip_package` (`trpid`, `root`, `price`, `tpname`, `duration`, `time`, `map`, `status`, `regdate`, `uid`, `vid`) VALUES
(2, 'Pune - Mumbai', 5000.00, 'Pune Mumbai', '1 Day', '10:30 AM', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30178.95972028877!2d73.92935672658258!3d19.00341242628081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdd30d128913813%3A0x908cd5c41e4b8673!2sManchar%2C%20Maharashtra%20410503!5e0!3m2!1sen!2sin!4v1584233740894!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>', 1, '2020-03-14', 1, 3),
(3, 'Manchar - Pune', 1200.00, 'Manchar - Pune', '1 Day', '10:30 AM', '&lt;iframe src=&quot;https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30178.95972028877!2d73.92935672658258!3d19.00341242628081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdd30d128913813%3A0x908cd5c41e4b8673!2sManchar%2C%20Maharashtra%20410503!5e0!3m2!1sen!2sin!4v1584233740894!5m2!1sen!2sin&quot; width=&quot;600&quot; height=&quot;450&quot; frameborder=&quot;0&quot; style=&quot;border:0;&quot; allowfullscreen=&quot;&quot; aria-hidden=&quot;false&quot; tabindex=&quot;0&quot;&gt;&lt', 0, '2020-03-15', 1, 4),
(4, 'Manchar - Pune', 1200.00, 'Manchar - Pune', '1 Day', '10:30 AM', '<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30178.95972028877!2d73.92935672658258!3d19.00341242628081!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bdd30d128913813%3A0x908cd5c41e4b8673!2sManchar%2C%20Maharashtra%20410503!5e0!3m2!1sen!2sin!4v1584233740894!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>', 1, '2020-03-15', 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `uid` int(9) NOT NULL,
  `uname` varchar(45) NOT NULL,
  `pass` varchar(20) NOT NULL,
  `uregdate` datetime NOT NULL,
  `utype` int(9) NOT NULL,
  `ustatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`uid`, `uname`, `pass`, `uregdate`, `utype`, `ustatus`) VALUES
(1, 'admin', 'admin', '2019-02-25 00:00:00', 1, 1),
(4, 'subhan', 'subhan', '2020-03-15 13:39:59', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `vid` int(9) NOT NULL,
  `vno` varchar(25) NOT NULL,
  `type` varchar(15) NOT NULL,
  `seater` tinyint(4) NOT NULL,
  `color` varchar(25) NOT NULL,
  `company` varchar(15) NOT NULL,
  `model` varchar(20) NOT NULL,
  `price` double(10,2) NOT NULL,
  `driver_name` varchar(20) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `imgpath` varchar(250) NOT NULL,
  `regdate` date NOT NULL,
  `status` tinyint(1) NOT NULL,
  `uid` int(9) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`vid`, `vno`, `type`, `seater`, `color`, `company`, `model`, `price`, `driver_name`, `contact`, `imgpath`, `regdate`, `status`, `uid`) VALUES
(1, '', 'Ac', 6, '0', 'Mahindra', 'Bolero', 15.00, 'Subhan', '8888789402', 'uploads/1_20200314030806.jpg', '2020-03-14', 0, 1),
(2, '', 'Ac', 6, 'Red', 'Mahindra', 'Bolero', 15.00, 'Subhan', '9975508577', 'uploads/1_20200314031055.png', '2020-03-14', 0, 1),
(3, 'MH 15 AB 1456', 'Ac', 7, 'Red', 'Mahindra', 'Bolero', 15.00, 'Subhan', '8888789402', 'uploads/1_20200314031203.jpg', '2020-03-14', 1, 1),
(4, 'MH 12 AB 1456', 'Ac', 6, 'Red', 'Mahindra', 'Bolero', 15.00, 'Subhan1', '8888789402', 'uploads/1_20200315015446.jpg', '2020-03-15', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `custom_booking`
--
ALTER TABLE `custom_booking`
  ADD PRIMARY KEY (`cbid`),
  ADD KEY `end_user` (`euid`),
  ADD KEY `vid` (`vid`);

--
-- Indexes for table `end_user`
--
ALTER TABLE `end_user`
  ADD PRIMARY KEY (`euid`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`fid`),
  ADD KEY `bid` (`euid`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`oid`),
  ADD KEY `bid` (`trpid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`pid`),
  ADD KEY `end_user` (`euid`);

--
-- Indexes for table `trip_booking`
--
ALTER TABLE `trip_booking`
  ADD PRIMARY KEY (`tbid`),
  ADD KEY `trip_package` (`trpid`),
  ADD KEY `end_user` (`euid`);

--
-- Indexes for table `trip_package`
--
ALTER TABLE `trip_package`
  ADD PRIMARY KEY (`trpid`),
  ADD KEY `admin` (`uid`),
  ADD KEY `vehical` (`vid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`vid`),
  ADD KEY `admin` (`status`),
  ADD KEY `aid` (`uid`),
  ADD KEY `status` (`status`),
  ADD KEY `status_2` (`status`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `custom_booking`
--
ALTER TABLE `custom_booking`
  MODIFY `cbid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `end_user`
--
ALTER TABLE `end_user`
  MODIFY `euid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `fid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `oid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `pid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `trip_booking`
--
ALTER TABLE `trip_booking`
  MODIFY `tbid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `trip_package`
--
ALTER TABLE `trip_package`
  MODIFY `trpid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `uid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `vid` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
